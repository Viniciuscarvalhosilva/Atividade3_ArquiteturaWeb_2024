package com.example.projetoescola.dtos;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
public class DadosFuncionarioDTO {
    private Long id;
    private String nome;
    private List<ProjetoDTO> projetos; // Adicione esta linha
}

